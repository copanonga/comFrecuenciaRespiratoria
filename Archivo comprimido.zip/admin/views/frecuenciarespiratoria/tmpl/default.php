<?php
defined('_JEXEC') or die;
?>

<h1>Frecuencia respiratoria</h1>