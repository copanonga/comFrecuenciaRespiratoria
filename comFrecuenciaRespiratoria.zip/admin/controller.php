<?php
defined('_JEXEC') or die;

class frecuenciarespiratoriaController extends JControllerLegacy
{
    
    public function display($cachable = false, $urlparams = false)
    {

        parent::display();
        return $this;

    }
        
}